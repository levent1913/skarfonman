#
# Example shell file for starting ethminer
# IMPORTANT: Replace the ETH address with your own ETH wallet address in the -wal option (Rig001 is the name of the rig)
./ethminer/ethminer -P stratum1+tcp://0xc4a02f2683d45dad7efb5bd29909b9e4d27eddf7.Rig001@eth-eu1.nanopool.org:9999
