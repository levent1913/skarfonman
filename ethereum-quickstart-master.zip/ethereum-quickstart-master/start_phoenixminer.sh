#
# Example shell file for starting PhoenixMiner to mine ETH
#
# IMPORTANT: Replace the ETH address with your own ETH wallet address in the -wal option (Rig001 is the name of the rig)
./phoenixminer/PhoenixMiner -pool eth-eu1.nanopool.org:9999 -wal 0xc4a02f2683d45dad7efb5bd29909b9e4d27eddf7/Rig001 -pass x
